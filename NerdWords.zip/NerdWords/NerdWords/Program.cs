﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace NerdWords
{
    class Program
    {
        //Track the execution time passed
        static Stopwatch stopWatch = new Stopwatch();

        static void Main(string[] args)
        {
            StreamReader inFile = null;
            StreamWriter outFile;
            string cheatCode;
            int validCount = 0;

            Console.Write("Enter a file name to test: ");
            inFile = IsFileValid(inFile);

            outFile = File.CreateText("Lane_T.txt"); //TODO: Replace the outFile file name

            //Reset and start the timer
            stopWatch.Reset();
            stopWatch.Start();

            //Read in one cheat code at a time to be validated
            while (!inFile.EndOfStream)
            {
                cheatCode = inFile.ReadLine();

                //Insert your code here to validate cheatCode and write the results to the file
                if (IsANerdWord(cheatCode))
                {
                    validCount++;
                    outFile.WriteLine(cheatCode + ":" + "YES");
                }
                else
				{
                    outFile.WriteLine(cheatCode + ":" + "NO");
                }
            }

            //Stop the timer and display results on the screen
            stopWatch.Stop();
            Console.WriteLine(GetTimeOutput(stopWatch));
            Console.WriteLine("Valid Nerd-Words: " + validCount);

            //Close the files
            inFile.Close();
            outFile.Close();
            Console.ReadLine();
        }

        public static string GetTimeOutput(Stopwatch timer)
        {
            TimeSpan ts = timer.Elapsed;
            return "Time- Days:Hours:Minutes:Seconds.Milliseconds:" + ts.Days + ":" + ts.Hours + ":" + ts.Minutes + ":" + ts.Seconds + "." + ts.Milliseconds;
        }

        public static bool IsANerdWord(string inputString)
		{
            if (inputString.StartsWith("A") && inputString.Contains("B"))
			{
                if (IsANerdWord(inputString.Substring(1, inputString.IndexOf("B") - 1)) || IsANerdWord(inputString.Substring(1, inputString.IndexOf("B")))) //scuffed
                {
                    return IsANerdWord(inputString.Substring(1, inputString.IndexOf("B") - 1) + inputString.Substring(inputString.IndexOf("B") + 1));
                }
            }
            else if (inputString.Equals("X"))
			{
                return true;
			}
            else if (inputString.Length > 1 && inputString.StartsWith("X") && inputString[1].Equals('Y'))
            {
                return IsANerdWord(inputString.Substring(2));
            }

            return false;
		}

        public static StreamReader IsFileValid(StreamReader inFile)
		{
            try
            {
                inFile = File.OpenText(Console.ReadLine());
            }
            catch
            {
                Console.Clear();
                Console.Write("Enter a file name to test: ");
                inFile = IsFileValid(inFile);
            }

            return inFile;
        }
    }
}